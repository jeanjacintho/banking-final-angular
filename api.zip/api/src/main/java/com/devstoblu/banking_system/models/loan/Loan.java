package com.devstoblu.banking_system.models.loan;

import com.devstoblu.banking_system.enums.loans.LoanStatus;
import com.devstoblu.banking_system.enums.loans.LoanType;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "loans")
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Valor total do empréstimo
    private BigDecimal totalAmount;

    // Taxa de juros (%)
    private BigDecimal interestRate;

    // Quantidade de parcelas
    private Integer numberOfInstallments;

    // Data de início
    private LocalDate startDate = LocalDate.now();

    // Tipo de empréstimo (PERSONAL, CONSIGNED)
    @Enumerated(EnumType.STRING)
    private LoanType type;

    // Status do empréstimo (EM_ANALISE, APROVADO, ATIVO, QUITADO, etc.)
    @Enumerated(EnumType.STRING)
    private LoanStatus status = LoanStatus.EM_ANALISE;

    // Relacionamento com as parcelas
    @OneToMany(mappedBy = "loan", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LoanInstallment> installments;

    public Loan() {}

    public Loan(BigDecimal totalAmount, BigDecimal interestRate, Integer numberOfInstallments, LoanType type) {
        this.totalAmount = totalAmount;
        this.interestRate = interestRate;
        this.numberOfInstallments = numberOfInstallments;
        this.type = type;
        this.startDate = LocalDate.now();
        this.status = LoanStatus.EM_ANALISE;
    }

    // Getters e setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public BigDecimal getInterestRate() { return interestRate; }
    public void setInterestRate(BigDecimal interestRate) { this.interestRate = interestRate; }

    public Integer getNumberOfInstallments() { return numberOfInstallments; }
    public void setNumberOfInstallments(Integer numberOfInstallments) { this.numberOfInstallments = numberOfInstallments; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LoanType getType() { return type; }
    public void setType(LoanType type) { this.type = type; }

    public LoanStatus getStatus() { return status; }
    public void setStatus(LoanStatus status) { this.status = status; }

    public List<LoanInstallment> getInstallments() { return installments; }
    public void setInstallments(List<LoanInstallment> installments) { this.installments = installments; }
}
