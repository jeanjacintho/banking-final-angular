package com.devstoblu.banking_system.dto;

public record LoginResponseDTO(String token) {
}
