package com.devstoblu.banking_system.enums;

public enum AccountType {
  CHECKING,
  SAVINGS
}
