package com.devstoblu.banking_system.enums.loans;

public enum LoanType {
    PERSONAL,
    CONSIGNED
}
