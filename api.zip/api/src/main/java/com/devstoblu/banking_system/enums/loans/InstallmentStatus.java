package com.devstoblu.banking_system.enums.loans;

public enum InstallmentStatus {
    PENDENTE, PAGO, ATRASADO
}
