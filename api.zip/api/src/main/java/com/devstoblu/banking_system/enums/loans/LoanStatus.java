package com.devstoblu.banking_system.enums.loans;

public enum LoanStatus {
    EM_ANALISE,
    APROVADO,
    REPROVADO,
    ATIVO,
    QUITADO,
    INADIMPLENTE
}
