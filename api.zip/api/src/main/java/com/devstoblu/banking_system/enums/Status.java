package com.devstoblu.banking_system.enums;

public enum Status {
    ATIVO,
    INATIVO,
    BLOQUEADO
}
