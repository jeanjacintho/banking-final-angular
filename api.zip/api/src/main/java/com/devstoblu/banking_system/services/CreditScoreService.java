package com.devstoblu.banking_system.services;

import com.devstoblu.banking_system.models.Usuario;
import com.devstoblu.banking_system.models.banking_account.Account;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;

@Service
public class CreditScoreService {

    /**
     * Calcula o score de crédito de um usuário baseado em:
     *  Tempo de conta (+10 pontos/ano)
     *  Saldo médio das contas (+1 ponto a cada R$100)
     *  Histórico de pagamentos (+50 se sem atrasos)
     * 4 Renda comprovada (+30 se > 0)
     */
    public int calculateScore(Usuario usuario) {
        int score = 0;

        // 1️⃣ Tempo de conta
        int years = Period.between(usuario.getDataNascimento(), LocalDate.now()).getYears();
        score += years * 10;

        BigDecimal totalBalance = BigDecimal.ZERO;
        int accountCount = 0;
        for (Account account : usuario.getAccounts()) {
            totalBalance = totalBalance.add(account.getAverageBalance());
            accountCount++;
        }
        if (accountCount > 0) {
            BigDecimal averageBalance = totalBalance.divide(BigDecimal.valueOf(accountCount), BigDecimal.ROUND_DOWN);
            score += averageBalance.divide(BigDecimal.valueOf(100), BigDecimal.ROUND_DOWN).intValue();
        }

        if (usuarioHasNoLatePayments(usuario)) {
            score += 50;
        }

        // 4️⃣ Renda comprovada
        if (usuario.getIncome() != null && usuario.getIncome().compareTo(BigDecimal.ZERO) > 0) {
            score += 30;
        }

        return score;
    }

    //Avalia elegibilidade do empréstimo baseado no score

    public String evaluateLoanEligibility(Usuario usuario) {
        int score = calculateScore(usuario);

        if (score > 300) return "APROVADO_AUTOMATICO";
        else if (score >= 200) return "APROVADO_MANUAL";
        else return "REPROVADO";
    }

    private boolean usuarioHasNoLatePayments(Usuario usuario) {
        // TODO: implementar verificação real usando histórico de contas e parcelas
        return true;
    }
}
