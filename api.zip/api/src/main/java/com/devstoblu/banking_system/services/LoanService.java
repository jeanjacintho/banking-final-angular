package com.devstoblu.banking_system.services;

import com.devstoblu.banking_system.enums.loans.InstallmentStatus;
import com.devstoblu.banking_system.enums.loans.LoanStatus;
import com.devstoblu.banking_system.enums.loans.LoanType;
import com.devstoblu.banking_system.models.loan.Loan;
import com.devstoblu.banking_system.models.loan.LoanInstallment;
import com.devstoblu.banking_system.repositories.loan.LoanInstallmentRepository;
import com.devstoblu.banking_system.repositories.loan.LoanRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class LoanService {

    private final LoanRepository loanRepository;
    private final LoanInstallmentRepository installmentRepository;

    public LoanService(LoanRepository loanRepository, LoanInstallmentRepository installmentRepository) {
        this.loanRepository = loanRepository;
        this.installmentRepository = installmentRepository;
    }

    public Loan createLoan(Loan loan) {
        // 1️⃣ Valida tipo e valor
        if (loan.getType() == LoanType.PERSONAL) {
            if (loan.getTotalAmount().compareTo(BigDecimal.valueOf(1000)) < 0 ||
                    loan.getTotalAmount().compareTo(BigDecimal.valueOf(50000)) > 0) {
                throw new IllegalArgumentException("Valor fora do limite para empréstimo pessoal");
            }
            loan.setInterestRate(BigDecimal.valueOf(0.025)); // 2.5% ao mês
        } else {
            if (loan.getTotalAmount().compareTo(BigDecimal.valueOf(2000)) < 0 ||
                    loan.getTotalAmount().compareTo(BigDecimal.valueOf(100000)) > 0) {
                throw new IllegalArgumentException("Valor fora do limite para empréstimo consignado");
            }
            loan.setInterestRate(BigDecimal.valueOf(0.015)); // 1.5% ao mês
        }

        // 2️⃣ Gera parcelas
        List<LoanInstallment> installments = new ArrayList<>();
        BigDecimal monthlyRate = loan.getInterestRate();
        BigDecimal installmentValue = loan.getTotalAmount()
                .multiply(BigDecimal.ONE.add(monthlyRate))
                .divide(BigDecimal.valueOf(loan.getNumberOfInstallments()), BigDecimal.ROUND_HALF_UP);

        for (int i = 1; i <= loan.getNumberOfInstallments(); i++) {
            LoanInstallment inst = new LoanInstallment();
            inst.setLoan(loan);
            inst.setNumber(i);
            inst.setDueDate(LocalDate.now().plusMonths(i));
            inst.setAmount(installmentValue);
            inst.setStatus(InstallmentStatus.PENDENTE);
            installments.add(inst);
        }

        loan.setInstallments(installments);
        loan.setStatus(LoanStatus.EM_ANALISE);
        return loanRepository.save(loan);
    }

    public List<Loan> getAllLoans() {
        return loanRepository.findAll();
    }
}
