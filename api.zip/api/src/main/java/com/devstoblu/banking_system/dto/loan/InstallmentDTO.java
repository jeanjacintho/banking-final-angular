package com.devstoblu.banking_system.dto.loan;

public class InstallmentDTO {

}
